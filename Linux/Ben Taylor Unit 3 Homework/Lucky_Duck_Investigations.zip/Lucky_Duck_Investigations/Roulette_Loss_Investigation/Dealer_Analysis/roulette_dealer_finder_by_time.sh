#!/bin/bash

cat $1_Dealer_schedule | grep -i $2
